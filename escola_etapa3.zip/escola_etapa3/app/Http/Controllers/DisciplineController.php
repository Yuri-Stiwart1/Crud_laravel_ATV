<?php


namespace App\Http\Controllers;


use App\Models\Discipline;
use Illuminate\Http\Request;


class DisciplineController extends Controller
{
    public function index()
    {
        $disciplines = Discipline::all(); // Busca todos os professores do banco de dados
        return view('disciplines.index', compact('disciplines')); // Retorna a view com os dados dos professores
    }
    public function create()
    {
        return view('disciplines.create'); // Retorna a view para criar um novo
    }


    public function store(Request $request)
    {
        // Valida os dados recebidos
        $request->validate([
            'discipline' => 'required|unique:disciplines',
            'city' => 'required',
        ]);
        // Cria um novo com os dados validados
        Discipline::create([
            'discipline' => $request->discipline,
            'city' => $request->city,
        ]);




        return redirect()->route('disciplines.index')->with('success', 'Professor criado com sucesso.');
    }
    public function edit($id)
    {
        $discipline = Discipline::findOrFail($id); // Busca o professor pelo ID ou retorna 404 se não encontrado
        return view('disciplines.edit', compact('discipline')); // Retorna a view de edição
    }


    public function update(Request $request, $id)
    {
        // Valida os dados recebidos
        $request->validate([
            'discipline' => 'required|unique:disciplines,discipline,' . $id,
            'city' => 'required',
        ]);
        // Busca o professor pelo ID
        $discipline = Discipline::findOrFail($id);
        // Atualiza os dados
        $discipline->update([
            'discipline' => $request->discipline,
            'city' => $request->city,
        ]);
        return redirect()->route('disciplines.index')->with('success', 'Professor atualizado com sucesso.');
    }


    public function destroy($id)
    {
        Discipline::findOrFail($id)->delete(); // Busca e o exclui
        return redirect()->route('disciplines.index')->with('success', 'Professor excluído com sucesso.');
    }
}
