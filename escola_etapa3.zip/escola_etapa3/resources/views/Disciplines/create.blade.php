@extends('layouts.app') <!-- Extende o layout base 'app.blade.php' -->


@section('content') <!-- Define a seção 'content' que será inserida no layout base -->
<h1>Adicionar Disciplina</h1>
<form action="{{ route('disciplines.store') }}" method="POST"> <!-- Formulário para adicionar um novo -->
    @csrf <!-- Token de proteção contra CSRF -->
    <div class="mb-3">
        <label for="nome" class="form-label">Nome da Disciplina</label>
        <input type="text" name="nome" id="nome" class="form-control" required> <!-- Campo para discipline -->
    </div>
    <div class="mb-3">
        <label for="cargahoraria" class="form-label">Carga Horária</label>
        <input type="text" name="cargahoraria" id="cargahoraria" class="form-control" required> <!-- Campo para senha -->
    </div>
    <button type="submit" class="btn btn-success">Adicionar</button> <!-- Botão para enviar o formulário -->
</form>
@endsection <!-- Fim da seção 'content' -->
