@extends('layouts.app') <!-- Extende o layout base 'app.blade.php' -->
@section('content') <!-- Define a seção 'content' que será inserida no layout base -->
<h1>Editar Disciplina</h1>
<form action="{{ route('disciplines.update', $discipline->id) }}" method="POST"> <!-- Formulário para editar um  existente -->
    @csrf <!-- Token de proteção contra CSRF -->
    @method('PUT') <!-- Método para atualizar -->
    <div class="mb-3">
        <label for="nome" class="form-label">Nome da Disciplina</label>
        <input type="text" name="nome" id="nome" class="form-control" value="{{ $discipline->discipline }}" required> <!-- Campo para discipline com valor atual -->
    </div>
    <div class="mb-3">
        <label for="cargahoraria" class="form-label">Carga Horária</label>
        <input type="text" name="cargahoraria" id="cargahoraria" class="form-control" required> <!-- Campo para nova senha -->
    </div>
    <button type="submit" class="btn btn-warning">Atualizar</button> <!-- Botão para enviar o formulário -->
</form>
@endsection <!-- Fim da seção 'content' -->
