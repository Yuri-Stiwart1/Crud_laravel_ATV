@extends('layouts.app') <!-- Extende o layout base 'app.blade.php' -->
@section('content') <!-- Define a seção 'content' que será inserida no layout base -->
<h1>Editar Professor</h1>
<form action="{{ route('teachers.update', $teacher->id) }}" method="POST"> <!-- Formulário para editar um  existente -->
    @csrf <!-- Token de proteção contra CSRF -->
    @method('PUT') <!-- Método para atualizar -->
    <div class="mb-3">
        <label for="teacher" class="form-label">Professor</label>
        <input type="text" name="teacher" id="teacher" class="form-control" value="{{ $teacher->teacher }}" required> <!-- Campo para teacher com valor atual -->
    </div>
    <div class="mb-3">
        <label for="city" class="form-label">Cidade</label>
        <input type="text" name="city" id="city" class="form-control" required> <!-- Campo para nova senha -->
    </div>
    <button type="submit" class="btn btn-warning">Atualizar</button> <!-- Botão para enviar o formulário -->
</form>
@endsection <!-- Fim da seção 'content' -->
